package com.jestogp9te;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JestoGP9TeApplication {
    public static void main(String[] args) {
        SpringApplication.run(JestoGP9TeApplication.class, args);
    }
}
